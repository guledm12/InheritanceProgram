/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceprogram;

import java.util.Scanner;
import java.lang.Math;

/**
 *
 * @author S331474189
 */
public class InheritanceProgram {
    public double A;
    public double cosA;
    public double B;
    public double sinB;
    public double C;
    /*double a;
    double b;
    double c;*/
    
     /* @param args the command line arguments
     */
    public static void main(String[] args) {
    double answer;
    System.out.println("\n1. 2 angles + 1 side");
    System.out.println("2. 2 sides + non included angle");
    System.out.println("3. 3 sides");
    System.out.println("4. 2 sides + included angle");
    Scanner p = new Scanner(System.in);
    System.out.println("Enter the number that corresponds with the info you know about the triangle.");
    answer = p.nextDouble(); 
    
    if (answer == 1) {
            //HI
        }
    
    else if (answer == 3){
            System.out.print("Enter your 'a' value: ");
            Scanner n = new Scanner(System.in);
            double a = n.nextDouble();
            System.out.print("Now enter your 'b' value: ");
            double b = n.nextDouble();
            System.out.print("Now enter your 'c' value: ");
            double c =n.nextDouble();
            IP3.CosineLawA(a, b, c);
            double cosA = IP3.CosineLawA(a, b, c);
            double A = (Math.acos(cosA) * 180/Math.PI);
            System.out.println("Angle A is " + A + " degrees.");
            double sinB = IP3.SineLawB(a, b, c);
            double B = (Math.asin(sinB) * 180 / Math.PI);
            System.out.println("Angle B is " + B + " degrees.");
            //System.out.println("Angle sinB is " + sinB + " degrees.");
            //System.out.println(Math.sin(A));
        }
    }
    
}
