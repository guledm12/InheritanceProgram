/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;
import java.lang.Math;
/**
 *
 * @author S331474189
 */
public class IP3 {
    public static double CosineLawA(double a, double b, double c) {
        //returns cosA
        return ((b * b) + (c * c) - (a * a)) / (2 * b * c);}
    
    public static double SineLawB(double a, double b, double A){
       //returns sinB
       return ( ((Math.sin(A)) / a) * b );
    }
}
