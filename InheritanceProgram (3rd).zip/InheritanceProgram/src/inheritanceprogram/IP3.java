/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;
import java.lang.Math;
/**
 *
 * @author S331474189
 */
public class IP3 {
    public static double cosineLawA(double a, double b, double c) {
        //returns cosA
        return ((b * b) + (c * c) - (a * a)) / (2 * b * c);}
    
    public static double sineLawB(double a, double b, double A){
       //returns sinB
       return ( (Math.sin(A)) / a * b );
    }
    
    public static double findC (double A, double B){
        //returns angle C
        return 180 - (A*180 / Math.PI) - (B*180 / Math.PI);
    }
}
