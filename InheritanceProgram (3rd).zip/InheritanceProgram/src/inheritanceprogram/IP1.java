/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;

/**
 *
 * @author S331474189
 */
public class IP1 {
    public static double  sineLawa (double A, double B, double b) {
        //returns line A.
        //double sinA = Math.sin(Math.toRadians(A));
        //double sinB = Math.sin(Math.toRadians(B));
        double sinA = Math.sin(A);
        double sinB = Math.sin(B);
        return b*(sinA/sinB);}
    
    public static double FindC(double A, double B) {
        //returns angle C.
        return 180-A-B;}
     
    public static double sineLawc (double C, double B, double b){
     //
        double sinB = Math.sin(B);
        double sinC = Math.sin(C);
        return sinC * (b / sinB);
    }
    }
    

