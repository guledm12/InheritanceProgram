/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceprogram;

import java.util.Scanner;

/**
 *
 * @author S331474189
 */
public class InheritanceProgram {
    double A;
    public double cosA;
    double B;
    double C;
    /*double a;
    double b;
    double c;*/
    
    public static double cosineLaw1 (double a, double b, double c) {
        //returns cosA
        return  ((b*b) + (c*c) - (a*a)) / 2*b*c;
    }
     /* @param args the command line arguments
     */
    public static void main(String[] args) {
    double answer;
    System.out.println("\n1. 2 angles + 1 side");
    System.out.println("2. 2 sides + non included angle");
    System.out.println("3. 3 sides");
    System.out.println("4. 2 sides + included angle");
    Scanner p = new Scanner(System.in);
    System.out.println("Enter the number that corresponds with the info you know about the triangle.");
    answer = p.nextDouble(); 
    
    //if (answer=1);
    double cos = cosineLaw1(5,3,2);
    System.out.println(cos);
    }
    
}
