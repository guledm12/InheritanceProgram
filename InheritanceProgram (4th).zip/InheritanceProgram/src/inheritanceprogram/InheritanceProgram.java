/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceprogram;

import java.util.Scanner;
import java.lang.Math;
import java.text.DecimalFormat;

/**
 *
 * @author S331474189
 */
public class InheritanceProgram {
    public double a;
    public double b;
    public double c;
    public double A;
    public double sinA;
    public double cosA;
    public double B;
    public double sinB;
    public double cosB;
    public double C;
    public double sinC;
    public double cosC;
    
     /* @param args the command line arguments
     */
    public static void main(String[] args) {
    DecimalFormat df = new DecimalFormat("#.##");
    
    double answer;
    System.out.println("\n1. 2 angles + 1 side");
    System.out.println("2. 2 sides + non included angle");
    System.out.println("3. 3 sides");
    System.out.println("4. 2 sides + included angle");
    Scanner p = new Scanner(System.in);
    System.out.println("Enter the number that corresponds with the info you know about the triangle.");
    answer = p.nextDouble(); 
    
    if (answer == 1) {
        Scanner n = new Scanner(System.in);
        System.out.println("Enter the value of Angle 'A': ");
        double A = n.nextDouble();
        System.out.println("Enter the value of Angle 'B': ");
        double B = n.nextDouble();
        System.out.println("Enter the value of line 'b': "); 
        double b = n.nextDouble();
        
        double a = IP1.sineLawa(A, B, b);
        a = Double.valueOf(df.format(a));
        System.out.println("Line 'a' has a value of: " + a );
        
        double C = IP1.FindC(A, B);
        System.out.println("Angle 'C' is " + C + " degrees.");
        C = Double.valueOf(df.format(C));
        
        double c = IP1.sineLawc(C, B, b);
        System.out.println("Line 'c' has a value of: " + c);
        }
    
    else if (answer == 2) {
           //HI
        }
    
    else if (answer == 3){
            //Allows you to enter your values.
            System.out.print("Enter your line 'a' value: ");
            Scanner n = new Scanner(System.in);
            double a = n.nextDouble();
            System.out.print("Now enter your line 'b' value: ");
            double b = n.nextDouble();
            System.out.print("Now enter your line 'c' value: ");
            double c = n.nextDouble();
            
            //Uses cosine law method from different class to find angle A.
            double cosA = IP3.cosineLawA(a, b, c);
            double A = (Math.acos(cosA));
            A = Double.valueOf(df.format(A));
            
            //Converts A from radians to degrees.
            System.out.println("Angle A is " + A*180/Math.PI + " degrees.");
            
            //Uses sine law method from different class to find angle B.
            double sinB = IP3.sineLawB(a, b, A);
            double B = (Math.asin(sinB));
            B = Double.valueOf(df.format(B));
            
            //Converts B from radians to degrees.
            System.out.println("Angle B is " + B*180/Math.PI + " degrees.");
            
            //Uses algebra to find final angle measurement.
            double C = IP3.findC(A, B);
            C = Double.valueOf(df.format(C));
            System.out.println("Angle C is " + C + " degrees.");
        }
    
    else if (answer ==4){
            System.out.print("Enter your line 'a' value: ");
            Scanner n = new Scanner(System.in);
            double a = n.nextDouble();
            System.out.print("Now enter your line 'b' value: ");
            double b = n.nextDouble();
            System.out.print("Now enter your included angle 'C' value: ");
            double C = n.nextDouble();
            
            //double c = Math.sqrt(IP4.findCSquared(a, b, C))
            double c = IP4.findCSquared(a, b, C);
            c = Double.valueOf(df.format(c));
            System.out.println("The value of line 'c' is " + c);
    }
    
    }    
}
