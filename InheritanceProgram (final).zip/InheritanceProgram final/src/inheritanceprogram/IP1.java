/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;

/**
 *
 * @author S331474189
 */
public class IP1 {
    public static double  sineLawa1 (double A, double B, double b) {
        //finds value of line a using sine law.
        double sinA = Math.sin(A);
        double sinB = Math.sin(B);
        return b*(sinA/sinB);}
    
    public static double FindC1(double A, double B) {
        //finds value of angle C using algebra.
        return 180-A-B;}
     
    public static double sineLawc1 (double C, double B, double b){
        //find value of line c using sine law.
        double sinB = Math.sin(B);
        double sinC = Math.sin(C);
        return sinC * (b / sinB);
    }
    }
    

