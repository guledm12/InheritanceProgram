/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;

/**
 *
 * @author S331474189
 */
public class IP2 {
    public static double sineLawB2(double a, double b, double A) {
        //finds value of line a using sine law.
        return (b * Math.sin(Math.toRadians(A)) / a);
    }
    
    public static double findC2(double A, double B){
        //finds the value of angle C using algebra.
        return (180-A-B);
    }
        
    public static double findc2(double B, double C, double b){
        //find the value of line C using sine law.
        return( Math.sin(Math.toDegrees(C)) * b / Math.sin(Math.toDegrees(B)) ) ;
    }
    }
        
       
  
