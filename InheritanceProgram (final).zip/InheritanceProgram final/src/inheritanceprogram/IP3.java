/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;
/**
 *
 * @author S331474189
 */
public class IP3 {
    public static double cosineLawA3(double a, double b, double c) {
        //finds the cos value of angle A. (actual angle value is calculated in master class)
        return ((b * b) + (c * c) - (a * a)) / (2 * b * c);}
    
    public static double sineLawB3(double a, double b, double A){
       //finds the sin value of angle B. (actual angle value is calculated in master class)
       return ( (Math.sin(Math.toRadians(A))) / a * b );
    }
    
    public static double findC3 (double A, double B){
        //finds value of angle C using algebra.
        return 180 - A - B;
    }
}
