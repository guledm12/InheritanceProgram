/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritanceprogram;

/**
 *
 * @author S331474189
 */
public class IP4 {
    public static double findcSquared4 (double a, double b, double C){
            //finds the  line value of c using the cosine law.
        double cosC = Math.cos(C*Math.PI/180);
        return Math.sqrt(((a*a) + (b*b) - (2*a*b*cosC)));
    }
    
    public static double findA4 (double a, double C, double c){
            //finds the  sin value of angle A. (actual angle value is calculated in master class)
        return (a * Math.sin(Math.toRadians(C)) / c);
    } 
        
    public static double FindB4(double A, double C) {
            //finds angle 'B' using algebra.
        return 180 - C - A;
    }
    }
    

