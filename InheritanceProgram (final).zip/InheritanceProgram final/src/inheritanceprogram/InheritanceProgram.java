/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritanceprogram;

import java.util.Scanner;
import java.lang.Math;
import java.text.DecimalFormat;

/**
 *
 * @author S331474189
 */
public class InheritanceProgram {
    public double a;
    public double b;
    public double c;
    public double A;
    public double sinA;
    public double cosA;
    public double B;
    public double sinB;
    public double cosB;
    public double C;
    public double sinC;
    public double cosC;
    
     /* @param args the command line arguments
     */
    public static void main(String[] args) {
    DecimalFormat df = new DecimalFormat("#.##");
    
    double answer;
    System.out.println("Welcome to our Triangle Calculator!");
    //Allows user to input the info it knows about the triangle.
    System.out.println("\n1. 2 angles + 1 side");
    System.out.println("2. 2 sides + non included angle");
    System.out.println("3. 3 sides");
    System.out.println("4. 2 sides + included angle");
    Scanner p = new Scanner(System.in);
    System.out.println("Enter the number that corresponds with the info you know about the triangle.");
    System.out.println("*NOTE* If you recieve negative values, then the info inputted is inaccurate or doesn't result in a real triangle.");
    System.out.print("Enter: ");
    answer = p.nextDouble(); 
    System.out.println(" ");
    
    if (answer == 1) {
        //Allows you to enter your values.
        Scanner n = new Scanner(System.in);
        System.out.println("Enter the value of Angle 'A': ");
        double A = n.nextDouble();
        System.out.println("Enter the value of Angle 'B': ");
        double B = n.nextDouble();
        System.out.println("Enter the value of line 'b': "); 
        double b = n.nextDouble();
        
        //Finds the line 'a' value.
        double a = IP1.sineLawa1(A, B, b);
        a = Double.valueOf(df.format(a));
        System.out.println("Line 'a' has a value of: " + a );
        
        //Find the angle 'C' value.
        double C = IP1.FindC1(A, B);
        System.out.println("Angle 'C' is " + C + " degrees.");
        C = Double.valueOf(df.format(C));
        
        //Finds the line 'c' value.
        double c = IP1.sineLawc1(C, B, b);
        System.out.println("Line 'c' has a value of: " + c);
        }
    
    else if (answer == 2) {
            //Allows you to enter your values.
            System.out.print("Enter your line 'a' value: ");
            Scanner n = new Scanner(System.in);
            double a = n.nextDouble();
            System.out.print("Now enter your line 'b' value: ");
            double b = n.nextDouble();
            System.out.print("Now enter your angle 'A' value: ");
            double A = n.nextDouble();
            
            //Finds and converts sinB to the real angle value of 'B'.
            double B = Math.toDegrees(Math.asin(IP2.sineLawB2(a, b, A)));
            B = Double.valueOf(df.format(B));
            System.out.println("Angle B is " + B + " degrees.");
            
            //Finds angle value 'C'.
            double C = IP2.findC2(A, B);
            C = Double.valueOf(df.format(C));
            System.out.println("Angle C is " + C + " degrees.");
            
            //Finds line value 'c'.
            double c = IP2.findc2(B, C, b);
            c = Double.valueOf(df.format(c));
            System.out.println("Line 'c' has a value of: " + c);  
            
        }
    
    else if (answer == 3){
            //Allows you to enter your values.
            System.out.print("Enter your line 'a' value: ");
            Scanner n = new Scanner(System.in);
            double a = n.nextDouble();
            System.out.print("Now enter your line 'b' value: ");
            double b = n.nextDouble();
            System.out.print("Now enter your line 'c' value: ");
            double c = n.nextDouble();
            
            //Finds and converts cosA to the real angle value of 'A'.
            double cosA = IP3.cosineLawA3(a, b, c);
            double A = (Math.acos(cosA));
            A = A * 180 / Math.PI;
            A = Double.valueOf(df.format(A));
            System.out.println("Angle A is " + A + " degrees.");
            
            //Finds angle value 'B'.
            double sinB = IP3.sineLawB3(a, b, A);
            double B = Math.asin(sinB);
            B = B*180/Math.PI;
            B = Double.valueOf(df.format(B));
            System.out.println("Angle B is " + B + " degrees.");
            
            //Finds angle value 'C'.
            double C = IP3.findC3(A, B);
            C = Double.valueOf(df.format(C));
            System.out.println("Angle C is " + C + " degrees.");
        }
    
    else if (answer ==4){
            System.out.print("Enter your line 'a' value: ");
            Scanner n = new Scanner(System.in);
            double a = n.nextDouble();
            System.out.print("Now enter your line 'b' value: ");
            double b = n.nextDouble();
            System.out.print("Now enter your included angle 'C' value: ");
            double C = n.nextDouble();
            
            //finds the line value of 'c'.
            double c = IP4.findcSquared4(a, b, C);
            c = Double.valueOf(df.format(c));
            System.out.println("The value of line 'c' is " + c);
            
            //Finds and converts sinA to actual 'A' value.
            double A = Math.toDegrees(Math.asin(IP4.findA4(a, C, c)));
            A = Double.valueOf(df.format(A));
            System.out.println("Angle A is " + A + " degrees.");
            
            //Finds angle 'B' value.
            double B = IP4.FindB4(A, C);
            B = Double.valueOf(df.format(B));
            System.out.println("Angle B is " + B + " degrees.");
            
           
    }
    
    }    
}
